package com.example.demo;

public class User {
    int id;
    String name;
    String userName;
    String passWord;

    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
