package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
public class AmazonController {
    @Autowired
    AmazonService service;

    private static Map<Integer,Integer> productMap = new HashMap<>();
    static{
        productMap.put(1,1);
        productMap.put(2,2);
    }

//    @GetMapping(path="/getDeal")
//    public void getDealApi(@RequestParam int productId){
////        service.buyProduct(productId);
//    }

    @PostMapping(path = "/onboardSeller")
    public ResponseEntity<String> onboardSeller(@RequestBody SellerInfoDto seller){
        try{
            service.registerSeller(seller.getSellerInstance());
            return new ResponseEntity<>("Onbaording Success",HttpStatus.OK);
        } catch (Exception e){
            return new ResponseEntity<>("Onbaording Failed",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(path = "/addProductForSeller")
    public void onboardSeller(@RequestParam Integer sellerId){
        Date startDate = new Date();
        Date endDate = new Date(2023,07,16,15,2);
        Time startTime = new Time(startDate.getTime());
        Time endTime = new Time(endDate.getTime());
        Deal d1 = new Deal(100,Map.copyOf(productMap),startTime,endTime);
        service.addDealsForSeller(sellerId,d1);
        System.out.println("Deal Added for Seller");
    }



    @PostMapping(path = "/placeOrder")
    public ResponseEntity<String> onboardSeller(@RequestParam Integer userId,@RequestParam Integer productId,@RequestParam Integer dealId){
        if(service.buyProduct(userId,productId,dealId)){
            System.out.println("Congrats Order Placed");
            return new ResponseEntity<>("Order Success",HttpStatus.OK);
        }
        return new ResponseEntity<>("Order Failed",HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
