package com.example.demo;

import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

@Service
public class AmazonService {
    Map<Integer,Seller> sellerList;
    private static Map<Integer,User> userMap = new HashMap<>();
    HashSet<String> orderDetails;

    static{
        userMap.put(1,new User(1,"Varun"));
        userMap.put(2,new User(2,"CharanJeet"));
        userMap.put(3,new User(3,"Gurpreet"));
    }


    public AmazonService(Map<Integer, Seller> sellerList) {
        this.sellerList = new HashMap<>();
        this.orderDetails = new HashSet<>();
    }

    public void registerSeller(Seller s1){
        System.out.println("Seller with id:: " + s1.getId() + " Onboarded on Amazon");
        sellerList.put(s1.getId(),s1);
    }

    public void deleteSeller(Seller s1){
        sellerList.remove(s1.getId(),s1);
    }

    public void addDealsForSeller(int sellerId,Deal d1){
        Seller s1 = sellerList.get(sellerId);
        if(s1 != null){
            System.out.println("Adding Deal for seller:: " + sellerId);
            s1.addDeal(d1);
        }
    }

    public boolean buyProduct(int userId,int productId,int dealId){

        for(Seller s1:sellerList.values()){
            if(s1.containsId(dealId)){
                Deal possibleDeal = s1.getDeal(dealId,productId);
                StringBuilder key = new StringBuilder();
                key.append(userId).append("_").append(productId);
                if(possibleDeal != null){
                    key.append("_").append(possibleDeal.getId());
                    if(!orderDetails.contains(key.toString())){
                        System.out.println("Purchase Done");
                        orderDetails.add(key.toString());
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
