package com.example.demo;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Seller {
    int id;
    List<Deal> dealList;
    String name;

    public Seller(int id, String name) {
        this.id = id;
        this.name = name;
        dealList = new ArrayList<>();
    }

    public void addDeal(Deal deal){
        dealList.add(deal);
        deal.toString();
    }

    public void removeDeal(Deal deal){
        dealList.remove(deal);
        deal.toString();
    }

    public Deal getDeal(int productId){
        Deal idealDeal = null;
        Time currentTime = new Time(new Date().getTime());
        for(Deal d1: dealList){
            if(d1.checkProductAvailability(productId,currentTime)){
                idealDeal = d1;
            }
        }
        return idealDeal;
    }
    public Deal getDeal(int dealId,int productId){
        Deal idealDeal = null;
        Time currentTime = new Time(new Date().getTime());
        for(Deal d1: dealList){
            if(d1.getId() == dealId && d1.getInventoryMap().containsKey(productId)){
                if(d1.checkProductAvailability(productId,currentTime)) {
                    idealDeal = d1;
                    break;
                }
            }
        }
        return idealDeal;
    }

    public int getId() {
        return id;
    }

    public boolean containsId(int dealId) {
        for(Deal d1:dealList){
            if(d1.getId() == dealId){
                return true;
            }
        }
        return false;
    }
}
