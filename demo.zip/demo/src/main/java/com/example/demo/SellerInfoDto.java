package com.example.demo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Map;

@JsonIgnoreProperties
public class SellerInfoDto {
    public int id;
    String name;

    public Seller getSellerInstance(){
        Seller s1 = new Seller(id,name);
        return s1;
    }
}
