package com.example.demo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.Time;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Deal {
    int id;
    Map<Integer,Integer> inventoryMap;
    Time startTime;
    Time endTime;
    boolean isActive;



    public Deal(int id, Map<Integer, Integer> inventoryMap, Time startTime, Time endTime) {
        this.id = id;
        this.inventoryMap = inventoryMap;
        if(startTime != null){
            this.startTime = startTime;
        } else{
            this.startTime = new Time(new Date().getTime());
        }
        this.endTime = endTime;
    }

    public int getId() {
        return id;
    }

    public Map<Integer, Integer> getInventoryMap() {
        return inventoryMap;
    }

    public void endDeal(Time endTime){
        isActive = false;
        this.endTime = endTime;
    }

    public boolean validatePurchaseTime(Time currentTime){
        if(currentTime.after(startTime) && currentTime.before(endTime)){
            return true;
        }
        return false;
    }


    public boolean checkProductAvailability(int productId,Time currentTime){
        if(inventoryMap.containsKey(productId) && inventoryMap.get(productId) > 0 && validatePurchaseTime(currentTime)){
            int quantity =  inventoryMap.get(productId) -1;
//            inventoryMap.put(productId, quantity);
            return true;
        }
        return false;
    }

    public void updateDeal(int quantity,Time endTime){
        inventoryMap.put(id,quantity);
        this.endTime = endTime;
    }

    @Override
    public String toString(){
        try {
            return "Deal: " + id + (new ObjectMapper().writeValueAsString(inventoryMap)).toString() + " startTime: " + startTime + " endTime" + endTime;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
